﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EXAMPLE.Model
{
    public class BusketBooks
    {
        public int ID_RECORD { get; set; }
        public int ID_BUSKET { get; set; }
        public int ID_BOOK { get; set; }
    }
}
