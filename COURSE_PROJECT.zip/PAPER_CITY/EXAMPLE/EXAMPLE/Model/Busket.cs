﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EXAMPLE.Model
{
    public class Busket
    {
        public int ID_BUSKET { get; set; }
        public int ID_USER { get; set; }
    }
}
